/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testOne; 

// IF THE PROJECT DOES NOT RUN WITHOUT ERRORS (RED UNDERLINES IN THE CODE) 2 POINTS ARE SUBSTRACTED FROM THE RESULT!!!
// At the end of the test you will have to Export your project to zip, so learn how to do it! (File->Export Project->To Zip)

/**
 *
 * @author kocsisg
 */
public class Kocsis { //Ex. 1 The project is created. The name of it is my family name. The package name is testOne (see above)
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Ex 7. Instantiate the new Person object (note that this exercise also can be done before Ex. 6.)
        Person p = new Person("Bob", 31, true);
        System.out.println(p); //If you see something like testOne.Person@123gsd in the output as a result of this line then your toString method in the Person class is wrong somehow
        
        //Ex. 8. 
        Student s = new Student("George", 25, true, 32);
        System.out.println(s);//If you see something like testOne.Student@123gsd in the output as a result of this line then your toString method in the Person class is wrong somehow
    
        //Ex. 10. calling the printOdd method till the credits of George 
        printOdd(s.getCredits()); //here you can not just write 32 because in that case if the credits of George changes the program will not be logically correct.
    }//main method
    
    public static void printOdd(int num){//Ex. 9. add this method. Note that is is in the Main class, but not inside the main method!
        for (int i=1;i<num;i=i+2){
            System.out.print(num + " "); // 
        }//for
        System.out.println();//Add a new line after the numbers
    }
}//Main class
