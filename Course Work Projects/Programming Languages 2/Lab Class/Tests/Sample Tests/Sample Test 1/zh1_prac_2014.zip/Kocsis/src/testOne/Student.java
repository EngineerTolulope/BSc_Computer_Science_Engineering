/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testOne;

/**
 *
 * @author kocsisg
 */
public class Student extends Person {//Ex. 6. This child class is created
    //The child class is added as a simple class and then I manually wrote the "extends Person" after the definition
   private int credits; //this is the extra attribute

   //The constructor has 4 parameters. The first 3 are set through the constructor of the super class
   //and the credits is set in the traditional way
    public Student(String name, int age, boolean sex, int credits) {
        super(name, age, sex);
        this.credits = credits;
    }
    
    public String toString(){
        //the super.toString calls the tpString method of the Person class so the name age and sex are printed by it
        //then the credits is appended.
        return super.toString() + " (credits: " + credits + ")";
    }

    //Getter and setter just as in the Person class
    /**
     * @return the credits
     */
    public int getCredits() {
        return credits;
    }

    /**
     * @param credits the credits to set
     */
    public void setCredits(int credits) {
        this.credits = credits;
    }
}
