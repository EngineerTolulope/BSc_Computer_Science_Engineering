/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gergely;

/**
 *
 * @author student
 */
public interface Printable {
    /**
     * The print method prints out the object to System.out
     */
    public void print();
}
