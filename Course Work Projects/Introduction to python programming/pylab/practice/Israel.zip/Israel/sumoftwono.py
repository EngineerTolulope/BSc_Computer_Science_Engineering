#!/usr/bin/env python
# coding: utf-8 



def main():
    a=int(raw_input("Give me a number..."))
    b=int(raw_input("Give me a number..."))
    print a+b
    
    
if __name__=="__main__":
    main()
