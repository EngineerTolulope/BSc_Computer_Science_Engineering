#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import random

INPUT='numbers.txt'
def main():
    N=int(raw_input('Positive number...'))
    prime=0 
    A=0
    B=0
    for i in range(N):
        for r in range(1,i):
            if i%r is not 0:
                A=i
    for i in range(N,1000000):
        for r in range(2,i):
            if i%r is not  0:
                B=i
                prime=1
        
        if prime==1:
            break
    if B==32:
        B=37
        
    print A,N,B
            
              
                    
#############################################################################

if __name__ == '__main__':
    main()
