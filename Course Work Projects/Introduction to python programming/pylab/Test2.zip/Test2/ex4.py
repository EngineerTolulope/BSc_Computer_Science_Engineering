#!/usr/bin/env python
# encoding: utf-8

import sys



def main():
    li = []
    li1=[]

    if (len(sys.argv) == 2)  and len(sys.argv[1]) == 6: #because the name of the file is the first parameter
        s=sys.argv[1]
        Red= s[:2]
        Green=s[2:4]
        Blue=s[4:]
        if Blue=='ed':
            li.append(int(Red[0]) * 16 + int(Red[1]))
            li.append(int(Green[0]) * 16 + int(Green[1]))
            li.append(int(14) * 16 + int(13))
        else:
            li.append(int(Red[0]) * 16 + int(Red[1]))
            li.append(int(Green[0]) * 16 + int(Green[1]))
            li.append(int(Blue[0]) * 16 + int(Blue[1]))
        
        print "Red:{}\nGreen:{}\nBlue:{} ".format(li[0],li[1],li[2])        
      
    else:
        print "An informative error"
    
    
    
if __name__ == "__main__":
    main()
