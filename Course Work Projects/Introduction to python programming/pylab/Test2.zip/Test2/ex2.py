#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import random

def main():
    n = 2**4096
    cli = []
    count = 0
    for i in n:
        if i not in cli:
            
#############################################################################

if __name__ == '__main__':
    main()
