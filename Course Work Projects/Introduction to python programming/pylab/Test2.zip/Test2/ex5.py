#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import random

INPUT='numbers.txt'
def main():
    f=open(INPUT,'r')
    li=[]
    for num in f:
        li.append(int(num))
    
    print max(li) - min(li)
    
    
    
    f.close()
      
#############################################################################

if __name__ == '__main__':
    main()
