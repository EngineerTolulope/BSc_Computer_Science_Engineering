#include <stdio.h>
#include <stdlib.h>

int main()
{
   //this is in while loop
   /* int num,sum=0,nonum=0;
   double avg;
    printf("Give me a number:-");
    scanf("%d", &num);
    while (num!=0)
       {
           sum+=num;
           ++nonum;
           avg=sum/(double)nonum;
           printf("Give me a number:-");
          scanf("%d", &num);

       }
    printf("The sum of the numbers is:-%d\nThe average of the numbers is:-%.2lf",sum,avg);*/

     int num,sum=0,nonum=0;
     double avg;
     do
     {
         printf("Give me a number:-");
        scanf("%d", &num);
         sum+=num;
         if (num!=0)
         {
             ++nonum;
           avg=sum/(double)nonum;
         }


     }
     while (num!=0);

     printf("The sum of the numbers is:-%d\nThe average of the numbers is:-%.2lf",sum,avg);


    return 0;
}
